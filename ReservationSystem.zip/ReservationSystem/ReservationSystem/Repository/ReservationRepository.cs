﻿using ReservationSystem.Models;
using System.Data.Common;
using Dapper;
using Microsoft.Data.SqlClient;
using ReservationSystem.IRepository;
using Microsoft.AspNetCore.Http.HttpResults;
using ReservationSystem.DataAccess;

namespace ReservationSystem.Repository
{
    public class ReservationRepository : IReservationRepository
    {
        private readonly DapperCtx _ctx;


        public ReservationRepository(DapperCtx ctx) => _ctx = ctx;

        public async Task<Reservation> GetReservationByIdAsync(int reservationId)
        {

            string query = "SELECT * FROM Reservations WHERE ReservationId = @ReservationId";
            using (var connection = _ctx.CreateConnection())
            {
                var reserv = await connection.QueryFirstOrDefaultAsync<Reservation>(query, new { ReservationId = reservationId });

                return reserv;

            }

        }

        public async Task AddReservationAsync(Reservation reservation)
        {

            string query = @"INSERT INTO Reservations (RegistrationDate, ReservationDate, UserId, PlaceId, Amount)
                             VALUES (@RegistrationDate, @ReservationDate, @UserId, @PlaceId, @Amount)";
            using (var connection = _ctx.CreateConnection())
            {
                await connection.ExecuteAsync(query, reservation);

            }

        }

        public async Task UpdateReservationAsync(Reservation reservation)
        {

            string query = @"UPDATE Reservations SET RegistrationDate = @RegistrationDate, ReservationDate = @ReservationDate,
                             UserId = @UserId, PlaceId = @PlaceId, Amount = @Amount WHERE ReservationId = @ReservationId";
            using (var connection = _ctx.CreateConnection())
            {
                await connection.ExecuteAsync(query, reservation);

            }

        }

        public async Task DeleteReservationAsync(int reservationId)
        {

            string query = "DELETE FROM Reservations WHERE ReservationId = @ReservationId";
            using (var connection = _ctx.CreateConnection())
            {
                await connection.ExecuteAsync(query, new { ReservationId = reservationId });

            }

        }
    }
}
