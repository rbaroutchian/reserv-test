﻿using ReservationSystem.Models;
using System.Data.Common;
using Dapper;
using Microsoft.Data.SqlClient;
using ReservationSystem.IRepository;
using ReservationSystem.DataAccess;

namespace ReservationSystem.Repository
{
    public class PlaceRepository : IPlaceRepository
    {
        private readonly DapperCtx _ctx;
        private object? place;

        public PlaceRepository(DapperCtx ctx) => _ctx = ctx;

        public async Task<Place> GetPlaceByIdAsync(int placeId)
        {

            var query = "SELECT * FROM Places WHERE PlaceId = @PlaceId";
            using (var connection = _ctx.CreateConnection())
            {

                var place = connection.QuerySingleOrDefaultAsync<Place>(query, new { PlaceId = placeId });
                return plase;
            }
        }

        public async Task<List<Place>> GetAllPlacesAsync()
        {

            string query = "SELECT * FROM Places";
            using (var connection = _ctx.CreateConnection())
            {
                return (await connection.QueryAsync<Place>(query)).AsList();

            }

        }

        public async Task AddPlaceAsync(Place place)
        {

            string query = @"INSERT INTO Places (Title, Address, Type, Location,  RegistrationDate, UserId)
                             VALUES (@Title, @Address, @Type, @Location, @RegistrationDate, @UserId)";
            using (var connection = _ctx.CreateConnection())
            {
                await connection.ExecuteAsync(query, place);

            }


        }

        public async Task UpdatePlaceAsync(Place place)
        {

            string query = @"UPDATE Places SET Title = @Title, Address = @Address, Type = @Type,
                             Laocation = @Location, RegistrationDate = @RegistrationDate,
                             UserId = @UserId WHERE PlaceId = @PlaceId";
            using (var connection = _ctx.CreateConnection())
            {
                await connection.ExecuteAsync(query, place);

            }

        }

        public async Task DeletePlaceAsync(int placeId)
        {

            string query = "DELETE FROM Places WHERE PlaceId = @PlaceId";
            using (var connection = _ctx.CreateConnection())
            {
                await connection.ExecuteAsync(query, new { PlaceId = placeId });

            }

        }
    }
}
