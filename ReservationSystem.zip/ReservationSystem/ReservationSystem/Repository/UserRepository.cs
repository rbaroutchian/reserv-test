﻿using Microsoft.Data.SqlClient;
using ReservationSystem.Models;
using System.Data;
using Dapper;
using System.Security.AccessControl;
using System.Data.Common;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory.Database;
using ReservationSystem.IRepository;
using ReservationSystem.DataAccess;

namespace ReservationSystem.Repository
{
    public class UserRepository : IuserRepository
    {


        private readonly DapperCtx _ctx;
        public UserRepository(DapperCtx ctx) => _ctx = ctx;



        public async Task<User> GetUserByIdAsync(int userId)
        {


            string query = "SELECT * FROM Users WHERE UserId = @UserId";
            using (var connection = _ctx.CreateConnection())
            {
                var user = await connection.QueryFirstOrDefaultAsync<User>(query, new { UserId = userId });
                return user;
            }

        }

        public async Task<User> GetUserByUsernameAsync(string username)
        {



            string query = "SELECT * FROM Users WHERE Username = @Username";
            using (var connection = _ctx.CreateConnection())
            {

                var user = await connection.QueryFirstOrDefaultAsync<User>(query, new { Username = username });
                return user;
            }

        }

        public async Task<List<User>> GetAllUsersAsync()
        {

            string query = "SELECT * FROM Users";
            using (var connection = _ctx.CreateConnection())
            {
                return (await connection.QueryAsync<User>(query)).AsList();

            }

        }

        public async Task<int> AddUserAsync(User user)
        {

            var query = @"INSERT INTO Users (Username, Password, IsActive, RegistrationDate)
                             VALUES (@Username, @Password, @IsActive, @RegistrationDate)";
            using (var connection = _ctx.CreateConnection())
            {
                var adduser = await connection.ExecuteAsync(query, user);
                return adduser;

            }

        }

        public async Task UpdateUserAsync(User user)
        {

            string query = @"UPDATE Users SET Username = @Username, Password = @Password, IsActive = @IsActive
                             WHERE UserId = @UserId";
            using (var connection = _ctx.CreateConnection())
            {
                var user = await connection.ExecuteAsync(query, user);
                return user;
            }

        }


        public async Task<int> DeleteUserAsync(int userId)
        {

            string query = "DELETE FROM Users WHERE UserId = @UserId";
            using (var connection = _ctx.CreateConnection())
            {
                var user = await connection.ExecuteAsync(query, new { UserId = userId });
                return user;
            }


        }
    }
}



