﻿using ReservationSystem.Models;
using ReservationSystem.IRepository;


namespace ReservationSystem.IRepository
{
    public interface IReservationRepository
    {
        public Task<Reservation> GetReservationByIdAsync(int reservationId);
        public Task AddReservationAsync(Reservation reservation);
        public Task UpdateReservationAsync(Reservation reservation);
        public Task DeleteReservationAsync(int reservationId);
    }
}
