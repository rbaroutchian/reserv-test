﻿using ReservationSystem.Models;

namespace ReservationSystem.IRepository
{
    public interface IPlaceRepository
    {
        public Task<Place> GetPlaceByIdAsync(int placeId);
        public Task<List<Place>> GetAllPlacesAsync();
        public Task AddPlaceAsync(Place place);
        public Task UpdatePlaceAsync(Place place);
        public Task DeletePlaceAsync(int placeId);
    }
}
