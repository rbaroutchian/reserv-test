﻿using ReservationSystem.Models;

namespace ReservationSystem.IRepository
{
    public interface IuserRepository
    {
        public Task<User> GetUserByIdAsync(int userId);
        public Task<User> GetUserByUsernameAsync(string username);
        public Task<List<User>> GetAllUsersAsync();
        public Task AddUserAsync(User user);
        public Task UpdateUserAsync(User user);
        public Task DeleteUserAsync(int userId);
    }


}
