﻿using System.Security.AccessControl;

namespace ReservationSystem.Models
{
    public class Place
    {
        public int PlaceId { get; set; }
        public string? Title { get; set; }
        public string? Address { get; set; }
        public PlaceType Type { get; set; }
        public string? Location { get; set; }
        public DateTime RegistrationDate { get; set; }
        public int UserId { get; set; }
    }
    public enum PlaceType
    {
        Recreational,
        Religious,
        Accommodation,
        Sports
    }
}
