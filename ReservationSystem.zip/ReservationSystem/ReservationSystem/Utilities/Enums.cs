﻿namespace ReservationSystem.Utilities
{
    public enum PlaceType
    {
        Recreation,
        Religious,
        Residential,
        Sports
    }

}
