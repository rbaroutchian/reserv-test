﻿using System.Collections.Generic;
namespace ReservationSystem.Utilities
{
    public class PaginationResult<T>
    {
        public required List<T> Items { get; set; }
        public int TotalCount { get; set; }
    }
}





