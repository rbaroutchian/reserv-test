﻿using ReservationSystem.IRepository;
using ReservationSystem.Models;

namespace ReservationSystem.Services
{
    public class UserServices
    {
        private readonly IUserRepository userRepository;

        public UserServices(IUserRepository userRepository)
        {
            this.userRepository = userRepository;
        }

        public void RegisterUser(string username, string password)
        {
            // Validate username and password
            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password))
            {
                throw new ArgumentException("Username and password cannot be empty.");
            }

            // Check if username already exists
            if (userRepository.GetUserByUsername(username) != null)
            {
                throw new Exception("Username already exists.");
            }

            // Register user
            User newUser = new User
            {
                Username = username,
                Password = password,
                IsActive = true,
                RegistrationDate = DateTime.Now
            };
            userRepository.AddUser(newUser);
        }

        public bool AuthenticateUser(string username, string password)
        {
            // Validate username and password
            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password))
            {
                return false;
            }

            // Check if user exists and password matches
            User user = userRepository.GetUserByUsername(username);
            if (user != null && user.Password == password)
            {
                return true;
            }

            return false;
        }
    }
}

