﻿using ReservationSystem.IRepository;
using ReservationSystem.Models;

namespace ReservationSystem.Services
{
    public class PlaceService
    {
        private readonly IPlaceRepository placeRepository;

        public PlaceService(IPlaceRepository placeRepository)
        {
            this.placeRepository = placeRepository;
        }

        public void AddPlace(string title, string address, string placeType, decimal latitude, decimal longitude, int creatorUserId)
        {
            // Validate input data
            if (string.IsNullOrWhiteSpace(title) || string.IsNullOrWhiteSpace(address) || string.IsNullOrWhiteSpace(placeType))
            {
                throw new ArgumentException("Title, address, and place type cannot be empty.");
            }

            // Add place
            Place newPlace = new Place
            {
                Title = title,
                Address =address,
                Type = type,
                Location = location,
                RegistrationDate = DateTime.Now,
                UserId = creatorUserId
            };
            placeRepository.AddPlace(newPlace);
        }

        public List<Place> SearchPlaces(string searchTerm, string placeType, int pageNumber, int pageSize)
        {
            // Implement search functionality
            return placeRepository.SearchPlaces(searchTerm, placeType, pageNumber, pageSize);
        }
    }
}

