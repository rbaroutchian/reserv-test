﻿using ReservationSystem.IRepository;
using ReservationSystem.Models;

namespace ReservationSystem.Services
{
    public class ReservationService
    {
        private readonly IReservationRepository reservationRepository;

        public ReservationService(IReservationRepository reservationRepository)
        {
            this.reservationRepository = reservationRepository;
        }

        public void MakeReservation(int userId, int placeId, decimal cost)
        {
            // Check if the place is available for reservation (implement this logic)

            // Make reservation
            Reservation newReservation = new Reservation
            {
                ReservationId = userId,
                RegistrationDate = DateTime.Now,
                ReservationDate = DateTime.Now,
                UserId = userId,
                PlaceId = placeId,
                Amount = cost
            };
            reservationRepository.AddReservation(newReservation);
        }
    }
}

