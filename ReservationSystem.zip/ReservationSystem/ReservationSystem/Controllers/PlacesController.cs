﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using ReservationSystem.Models;
using ReservationSystem.Services;

namespace ReservationSystem.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PlaceController : ControllerBase
    {
        private readonly PlaceService placeService;

        public PlaceController(PlaceService placeService)
        {
            this.placeService = placeService;
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetPlace(int id)
        {
            try
            {
                var place = await placeService.GetPlaceByIdAsync(id);
                if (place == null)
                {
                    return NotFound();
                }
                return Ok(place);
            }
            catch (Exception)
            {
                return StatusCode(500, "An error occurred while retrieving the place.");
            }
        }

        [HttpPost]
        public async Task<IActionResult> AddPlace([FromBody] PlaceModel model)
        {
            try
            {
                await placeService.AddPlaceAsync(model.Title, model.Address, model.PlaceType, model.Latitude, model.Longitude, model.RegistrationDate, model.CreatorUserId);
                return Ok("Place added successfully.");
            }
            catch (ArgumentException ex)
            {
                return BadRequest(ex.Message);
            }
            catch (Exception)
            {
                return StatusCode(500, "An error occurred while adding the place.");
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdatePlace(int id, [FromBody] PlaceModel model)
        {
            try
            {
                await placeService.UpdatePlaceAsync(id, model.Title, model.Address, model.PlaceType, model.Latitude, model.Longitude, model.RegistrationDate, model.CreatorUserId);
                return Ok("Place updated successfully.");
            }
            catch (ArgumentException ex)
            {
                return BadRequest(ex.Message);
            }
            catch (Exception)
            {
                return StatusCode(500, "An error occurred while updating the place.");
            }
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeletePlace(int id)
        {
            try
            {
                await placeService.DeletePlaceAsync(id);
                return Ok("Place deleted successfully.");
            }
            catch (Exception)
            {
                return StatusCode(500, "An error occurred while deleting the place.");
            }
        }
    }
}