﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ReservationSystem.Models;
using ReservationSystem.Services;



namespace ReservationSystem.Controllers
{
    using Microsoft.AspNetCore.Mvc;
    using System;
    using System.Threading.Tasks;

    [Route("api/[controller]")]
    [ApiController]
    public class ReservationController : ControllerBase
    {
        private readonly ReservationService reservationService;

        public ReservationController(ReservationService reservationService)
        {
            this.reservationService = reservationService;
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetReservation(int id)
        {
            try
            {
                var reservation = await reservationService.GetReservationByIdAsync(id);
                if (reservation == null)
                {
                    return NotFound();
                }
                return Ok(reservation);
            }
            catch (Exception)
            {
                return StatusCode(500, "An error occurred while retrieving the reservation.");
            }
        }

        [HttpPost]
        public async Task<IActionResult> MakeReservation([FromBody] ReservationModel model)
        {
            try
            {
                await reservationService.MakeReservationAsync(model.UserId, model.PlaceId, model.ReservationDate, model.BookingDate, model.Cost);
                return Ok("Reservation made successfully.");
            }
            catch (Exception)
            {
                return StatusCode(500, "An error occurred while making the reservation.");
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateReservation(int id, [FromBody] ReservationModel model)
        {
            try
            {
                await reservationService.UpdateReservationAsync(id, model.UserId, model.PlaceId, model.ReservationDate, model.BookingDate, model.Cost);
                return Ok("Reservation updated successfully.");
            }
            catch (ArgumentException ex)
            {
                return BadRequest(ex.Message);
            }
            catch (Exception)
            {
                return StatusCode(500, "An error occurred while updating the reservation.");
            }
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteReservation(int id)
        {
            try
            {
                await reservationService.DeleteReservationAsync(id);
                return Ok("Reservation deleted successfully.");
            }
            catch (Exception)
            {
                return StatusCode(500, "An error occurred while deleting the reservation.");
            }
        }
    }
}