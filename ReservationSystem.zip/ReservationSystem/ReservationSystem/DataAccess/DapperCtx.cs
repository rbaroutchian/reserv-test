﻿using Microsoft.Data.SqlClient;
using System.Data;

namespace ReservationSystem.DataAccess
{
    public class DapperCtx
    {
        private readonly IConfiguration _configuration;
        private readonly string? _ConnectionString;

        public DapperCtx(IConfiguration configuration)
        {
            _configuration = configuration;
            _ConnectionString = _configuration.GetConnectionString("SQLconnection");
        }

        public IDbConnection CreateConnection() => new SqlConnection(_ConnectionString);
    }
}

